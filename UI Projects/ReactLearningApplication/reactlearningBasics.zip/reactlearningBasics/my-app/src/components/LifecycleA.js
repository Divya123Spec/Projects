import React, { Component } from "react";
import LifecycleB from "./LifecycleB";

export class LifecycleA extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "Divya",
    };
    console.log("LifecycleA consturctor");
  }

  static getDerivedStateFormProps(props, state) {
    console.log("LifeCleA getDerivedStateFormProps ");
    return null;
  }

  componentDidMount() {
    console.log("LifeCycleA componentDidMount ");
  }

  shouldComponentUpdate() {
    console.log("LifecycleA shouldComponentUpdate");
    return true;
  }
  getSnapshotBeforeUpdate() {
    console.log("LifecycleA getSnapshotBeforeUpdate");
    return null;
  }
  componentDidUpdate() {
    console.log("LifecycleA componentDidUpdate");
  }
  changeState = () => {
      console.log('sdfghjk')
    this.setState({
      name: "Codevolution",
    });
  };
  render() {
    console.log("LifeCycleA render");
    return (
      <div>
        <div>LifecycleA</div>
        <button onChange={this.changeState}>Change state</button>
        <LifecycleB />
      </div>
    );
  }
}

export default LifecycleA;
