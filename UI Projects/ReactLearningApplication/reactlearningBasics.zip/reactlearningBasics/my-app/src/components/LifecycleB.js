import React, { Component } from 'react'

export class LifecycleB extends Component {
constructor(props) {
  super(props)

  this.state = {
     name:'Divya'
  }
  console.log('LifecycleB consturctor')
}

static getDerivedStateFormProps(props,state){
    console.log('LifeCleB getDerivedStateFormProps ')
    return null
}


componentDidMount(){
    console.log('LifeCycleB componentDidMount ')
}


shouldComponentUpdate(){
    console.log('LifecycleB shouldComponentUpdate')
    return true
}
getSnapshotBeforeUpdate(){
    console.log('LifecycleB getSnapshotBeforeUpdate')
    return null
}
componentDidUpdate(){
    console.log('LifecycleB componentDidUpdate')
}
  render() {
  console.log('LifeCycleB render')
    return (
      <div>LifecycleB</div>
    )
  }
}

export default LifecycleB