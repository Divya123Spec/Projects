import React from 'react'
import './MyStyle.css'

function StyleSheet(props) {
   let  className = props.Secondary ? 'Secondary' :''
  return (
    <div>

        // normal way applying css by importing css file
        <h1 className='primary'>Stylesheet</h1>

        // by conditionlly we can apply css to text
        <h2 className={className}>Stylesheet</h2>

        // using template litarate
        <h2 className={`${className} font-xl`}>Stylesheet</h2>
    </div>
  )
}

export default StyleSheet