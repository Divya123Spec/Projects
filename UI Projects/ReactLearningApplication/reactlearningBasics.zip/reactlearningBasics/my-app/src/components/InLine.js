import React from 'react'


const heading ={
    color: 'blue'
}
function InLine() {
  return (
    <div style={heading}>InLine</div>
  )
}

export default InLine