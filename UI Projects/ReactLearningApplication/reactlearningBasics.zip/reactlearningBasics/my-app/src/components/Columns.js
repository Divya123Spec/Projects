import React from 'react'

function Columns() {
  return (
    <React.Fragment>
    <td>Name</td>
    <td>Vishwas</td>
    </React.Fragment>
  )
}

export default Columns