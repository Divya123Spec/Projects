// const { slice } = require("lodash");

// // reduce
// let numbers = [2, 4, 6, 8, 10];

// // function to return the square of a number
// function square(number) {
//   return number * number;
// }

// // apply square() function to each item of the numbers list
// let square_numbers = numbers.map(square);
// console.log(square_numbers);

// // Output: [ 4, 16, 36, 64, 100 ]

// // Splice
// const months = ['Jan', 'March', 'April', 'June'];
// months.splice(1, 0, 'Feb');
// // inserts at index 1
// console.log(months);
// // expected output: Array ["Jan", "Feb", "March", "April", "June"]

// months.splice(4, 1, 'May');
// // replaces 1 element at index 4
// console.log(months);
// // expected output: Array ["Jan", "Feb", "March", "April", "May"]

// // slice
// const animals = ['ant', 'bison', 'camel', 'duck', 'elephant'];

// console.log(animals.slice(2));
// // expected output: Array ["camel", "duck", "elephant"]

// console.log(animals.slice(2, 4));
// // expected output: Array ["camel", "duck"]

// console.log(animals.slice(1, 5));
// // expected output: Array ["bison", "camel", "duck", "elephant"]

// console.log(animals.slice(-2));
// // expected output: Array ["duck", "elephant"]

// console.log(animals.slice(2, -1));
// // expected output: Array ["camel", "duck"]

// console.log(animals.slice());
// // expected output: Array ["ant", "bison", "camel", "duck", "elephant"]

// // sort
// const month = ['March', 'Jan', 'Feb', 'Dec'];
// months.sort();
// console.log(month);
// // expected output: Array ["Dec", "Feb", "Jan", "March"]

// const array1 = [1, 30, 4, 21, 100000];
// array1.sort();
// console.log(array1);
// // expected output: Array [1, 100000, 21, 30, 4]

// // Split
// const str = 'The quick brown fox jumps over the lazy dog.';

// const words = str.split(' ');
// console.log(words[3]);
// // expected output: "fox"

// const chars = str.split('');
// console.log(chars[8]);
// // expected output: "k"

// const strCopy = str.split();
// console.log(strCopy);
// // expected output: Array ["The quick brown fox jumps over the lazy dog."]


// fibonaci 


// const number = parseInt(prompt('Enter the number of terms: '));
// let number1 = 0, number2 = 1, lastnum;
// let number =32;
// for (let i = 1; i <= number; i++) {
//     console.log(number1);
//     nextTerm = number1 + number2;
//     number1 = number2;
//     number2 = lastnum;
// }


function fibonacci(num) {
  if(num < 2) {
      return num;
  }
  else {
      return fibonacci(num-1) + fibonacci(num - 2);
  }
}

const nTerms =5

if(nTerms <=0) {
}
else {
  for(let i = 0; i < nTerms; i++) {
      console.log(fibonacci(i));
  }
}


let text1 = "Hello";
let text2 = "world!";
let text3 = "Have a nice day!";
let result = text1.concat(" ", text2, " ", text3);
console.log('result',result);


// palndrome

const checkPalindrome = (string) => {
  // convert string to an array
let arrayValues = string.split('');
console.log('arrayValues',arrayValues)

    // reverse the array values
let arrayReverse = arrayValues.reverse();
console.log('arrayReverse',arrayReverse)

 // convert array to string
 const reverseString = arrayReverse.join('');
 console.log('reverseString',reverseString)
if(string == reverseString) {
  console.log('It is a palindrome');
}
else {
  console.log('It is not a palindrome');
}
}


const string = 'dad';

checkPalindrome(string);