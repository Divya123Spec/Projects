import React from 'react'

export default function MemoComp({name}) {
    console.log('redering memo comp')
  return (
    <div>
    {name}
    </div>
  )
}
