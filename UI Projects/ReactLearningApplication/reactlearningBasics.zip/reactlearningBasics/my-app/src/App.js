import logo from "./logo.svg";
import "./App.css";
import StyleSheet from "./components/StyleSheet";
import InLine from "./components/InLine";
import Form from "./components/Form";
import "./appStyle.css";
import styles from "./appStyle.module.css";
import LifecycleA from "./components/LifecycleA";
import FragmentDemo from "./components/FragmentDemo";
import Table from "./components/Table";
import PureComp from "./components/PureComp";
import RegComp from "./components/RegComp";
import ParentComp from "./components/ParentComp";
import FRParentInput from "./components/FRParentInput";
import PortalDemo from "./components/PortalDemo";
import Hero from "./components/Hero";
import ErrorBoundary from "./components/ErrorBoundary";
import ClickCounters from "./components/ClickCounters";
import HoverCounter from "./components/HoverCounter";
import ClickCounterTwo from "./components/ClickCounterTwo";
import HoverCounterTwo from "./components/HoverCounterTwo";
import User from "./components/User";
import Counter from './components/Counter'
import { UserProvider } from "./components/UserContext";
import ComponentC from "./components/ComponentC";

function App() {
  return (
    <div className="App">
      <h1 className="error">Error</h1>
      <h1 className={styles.success}>Success</h1>

      <UserProvider value ="Divya">
      <ComponentC></ComponentC>
      </UserProvider>
   {/*
      <Counter
        render={(count, incrementCount) => (
          <ClickCounterTwo count={count} incrementCount={incrementCount} />
        )}
      />
      <Counter
      render={(count, incrementCount) => (
        <HoverCounterTwo count={count} incrementCount={incrementCount} />
      )}
    />
   */}
      {/* <User render={(isLoggedIn) => (isLoggedIn ? "Divya" : "guest")}></User>
      <HoverCounterTwo></HoverCounterTwo>
      <ClickCounterTwo></ClickCounterTwo>
      <ClickCounters></ClickCounters>
  <HoverCounter></HoverCounter> */}

      {/*<ErrorBoundary>
      <Hero heroname='Batname'></Hero>
      <Hero heroname='Superman'></Hero>
      <Hero heroname='Joker'></Hero> 
  </ErrorBoundary>*/}
      {/* <FRParentInput></FRParentInput>
      <StyleSheet Secondary={false}></StyleSheet>
      <InLine></InLine>
      <Form></Form>
      <LifecycleA></LifecycleA>
      <FragmentDemo></FragmentDemo>
      <Table></Table>
  <ParentComp></ParentComp> */}
    </div>
  );
}

export default App;
